BOT DE DISCORD - MOLDURA 2.png com FUNDO TRANSPARENTE

✔ Área branca foi removida (agora é transparente)
✔ Imagem enviada será visível corretamente

Área de encaixe:
x: 170
y: 200
width: 1580
height: 700

1. Coloque seu token em config.json
2. Execute:
   npm install
3. Inicie com:
   node index.js
