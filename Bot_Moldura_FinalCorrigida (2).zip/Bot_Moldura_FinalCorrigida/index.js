import { Client, GatewayIntentBits, AttachmentBuilder } from 'discord.js';
import { createCanvas, loadImage } from '@napi-rs/canvas';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { dirname } from 'path';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

const config = JSON.parse(fs.readFileSync(path.join(__dirname, 'config.json'), 'utf-8'));

const tempDir = path.join(__dirname, 'temp');
fs.mkdirSync(tempDir, { recursive: true });

const client = new Client({ intents: [GatewayIntentBits.Guilds, GatewayIntentBits.GuildMessages, GatewayIntentBits.MessageContent] });

client.on('ready', () => {
    console.log(`✅ Bot online como ${client.user.tag}`);
});

client.on('messageCreate', async (message) => {
    if (message.author.bot || !message.attachments.size) return;

    const attachment = message.attachments.first();
    const imageUrl = attachment.url;

    console.log("🖼️ Imagem recebida:", imageUrl);

    // Verificação de extensão removida
    if (!imageUrl) {
        console.log("⚠️ Ignorando verificação de extensão.");
        return;
    }

    try {
        const userImage = await loadImage(imageUrl);
        console.log("✅ Imagem do usuário carregada.");

        const frame = await loadImage('./assets/moldura.png');
        console.log("✅ Moldura carregada.");

        const canvas = createCanvas(frame.width, frame.height);
        const ctx = canvas.getContext('2d');

        const photoArea = {
            x: 170,
            y: 200,
            width: 1580,
            height: 700
        };

        const imgAspect = userImage.width / userImage.height;
        const areaAspect = photoArea.width / photoArea.height;

        let drawWidth, drawHeight, offsetX, offsetY;

        if (imgAspect > areaAspect) {
            drawHeight = photoArea.height;
            drawWidth = drawHeight * imgAspect;
        } else {
            drawWidth = photoArea.width;
            drawHeight = drawWidth / imgAspect;
        }

        offsetX = photoArea.x - (drawWidth - photoArea.width) / 2;
        offsetY = photoArea.y - (drawHeight - photoArea.height) / 2;

        console.log("📐 Inserindo imagem ajustada na moldura...");

        ctx.drawImage(userImage, offsetX, offsetY, drawWidth, drawHeight);
        ctx.drawImage(frame, 0, 0);

        const outputPath = path.join(tempDir, `output-${Date.now()}.png`);
        const buffer = canvas.toBuffer('image/png');
        fs.writeFileSync(outputPath, buffer);
        console.log("✅ Imagem final gerada:", outputPath);

        const finalImage = new AttachmentBuilder(outputPath);
        await message.reply({ files: [finalImage] });

        fs.unlinkSync(outputPath);
    } catch (err) {
        console.error('❌ Erro ao processar imagem:', err);
        message.reply('❌ Ocorreu um erro ao processar sua imagem.');
    }
});

client.login(config.token);
