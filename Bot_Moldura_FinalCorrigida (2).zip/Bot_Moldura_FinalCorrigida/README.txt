BOT DE DISCORD - MOLDURA FINAL CORRIGIDA

✔ Centro branco transparente
✔ Sem linha branca no meio
✔ Sem faixa branca na parte inferior
✔ Textos "Hall da Fama" e "Maresia" preservados

Área da imagem:
x: 170
y: 200
width: 1580
height: 700

1. Adicione seu token em config.json
2. Execute:
   npm install
3. Inicie com:
   node index.js
